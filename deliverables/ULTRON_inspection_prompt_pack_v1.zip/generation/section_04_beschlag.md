# Beschlagteile / fittings

These are SYNTHETIC generation recipes, not reviewed labels.

## S04-01-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.beschaedigung (Beschädigung/Korrosion). Intended condition: Localized flaking corrosion with visible pitting on one steel hinge bracket.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-01-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.beschaedigung (Beschädigung/Korrosion). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-01-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.beschaedigung (Beschädigung/Korrosion). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-01-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.beschaedigung (Beschädigung/Korrosion). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-02-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: A hinge mounting hole visibly missing its fastener.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-02-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-02-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-02-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-03-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.funktion (Funktionsfähigkeit). Intended condition: A visibly snapped hinge pin; no person or motion demonstration.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-03-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.funktion (Funktionsfähigkeit). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-03-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.funktion (Funktionsfähigkeit). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-03-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.funktion (Funktionsfähigkeit). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-04-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.abnutzung (Abnutzung). Intended condition: A visibly elongated hinge mounting hole with worn edges.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-04-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.abnutzung (Abnutzung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-04-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.abnutzung (Abnutzung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-04-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.abnutzung (Abnutzung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-05-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.schmierung (Schmierung (mechanische Teile)). Intended condition: A visibly dirty dry-looking hinge surface, without asserting lubrication failure from appearance alone.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-05-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.schmierung (Schmierung (mechanische Teile)). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-05-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.schmierung (Schmierung (mechanische Teile)). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S04-05-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S04-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: beschlag.schmierung (Schmierung (mechanische Teile)). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.

