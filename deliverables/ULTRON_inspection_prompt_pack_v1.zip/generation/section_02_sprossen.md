# Sprossen/Stufen/Plattform / rungs, steps, platform

These are SYNTHETIC generation recipes, not reviewed labels.

## S02-01-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verformung (Verformung). Intended condition: One rung visibly bent downward at its centre.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-01-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verformung (Verformung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-01-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verformung (Verformung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-01-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verformung (Verformung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-02-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.beschaedigung (Beschädigung). Intended condition: One rung with a clearly broken end and an exposed gap at the rail.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-02-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.beschaedigung (Beschädigung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-02-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.beschaedigung (Beschädigung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-02-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.beschaedigung (Beschädigung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-03-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-03: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: A visibly splintered wooden step edge without a person touching it.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-03-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-03: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-03-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-03: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-03-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-03: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-04-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verbindung (Verbindung zum Holm). Intended condition: A visibly separated rung-to-rail joint with a missing rivet.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-04-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verbindung (Verbindung zum Holm). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-04-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verbindung (Verbindung zum Holm). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-04-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.verbindung (Verbindung zum Holm). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-05-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.abnutzung (Abnutzung (Trittfläche, Plattformauflage)). Intended condition: One heavily worn tread with locally flattened anti-slip grooves.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-05-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.abnutzung (Abnutzung (Trittfläche, Plattformauflage)). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-05-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.abnutzung (Abnutzung (Trittfläche, Plattformauflage)). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S02-05-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S02-05: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: sprossen.abnutzung (Abnutzung (Trittfläche, Plattformauflage)). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.

