# Holme / rails

These are SYNTHETIC generation recipes, not reviewed labels.

## S01-01-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.verformung (Verformung). Intended condition: A localized permanent kink midway along the right rail; no other intended defect.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-01-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.verformung (Verformung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-01-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.verformung (Verformung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-01-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.verformung (Verformung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-02-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.beschaedigung (Beschädigung (z.B. Risse)). Intended condition: A visible short branching crack at a rail junction, with material separation rather than a painted line.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-02-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.beschaedigung (Beschädigung (z.B. Risse)). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-02-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.beschaedigung (Beschädigung (z.B. Risse)). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-02-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-02: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.beschaedigung (Beschädigung (z.B. Risse)). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-03-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: A visibly raised metal burr on an exposed rail edge; do not imply a tactile test.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-03-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-03-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-03-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-03: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.kanten (Scharfe Kanten, Splitter, Grat). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-04-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.abnutzung (Abnutzung). Intended condition: Localized deep abrasion with visible material loss on the rail.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-04-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.abnutzung (Abnutzung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-04-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.abnutzung (Abnutzung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-04-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-04: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.abnutzung (Abnutzung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-05-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-05: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.schutz (Schutzbehandlung (bei Holz)). Intended condition: A wooden ladder rail with peeling coating and exposed wood; treatment adequacy remains unverified.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-05-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-05: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.schutz (Schutzbehandlung (bei Holz)). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-05-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-05: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.schutz (Schutzbehandlung (bei Holz)). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S01-05-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S01-05: one portable wooden A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: holme.schutz (Schutzbehandlung (bei Holz)). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.

