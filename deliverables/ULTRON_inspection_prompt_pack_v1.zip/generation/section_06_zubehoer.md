# Zubehör / accessories

These are SYNTHETIC generation recipes, not reviewed labels.

## S06-01-visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S06-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: zubehoer.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: A fitted stabilizer bar visibly detached at one endpoint; show the mounting context.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S06-01-no_visible_defect

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S06-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: zubehoer.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: No visible defect on the target component. Normal realistic wear only. Do not imply physical safety or completed functional checks.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S06-01-hard_negative

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S06-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: zubehoer.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: A superficial dirt streak, shadow or non-structural cosmetic scuff near the target. Keep target geometry intact. Do not turn the cosmetic mark into an actual crack or missing part.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.


## S06-01-unobservable

Photorealistic construction-site inspection dataset photograph, not a diagram or advertising image.
Subject identity S06-01: one portable aluminium A-frame/platform stepladder, consistent rail/rung count, joints, dimensions and local component details across this scene's views. Neutral building-site lighting, realistic camera noise and material texture. No people, logos, answer text, bounding boxes, watermarks or safety verdict overlays. No stylistic colour cue correlated with condition. Use the same background family across all condition variants.
Target criterion: zubehoer.vollstaendigkeit (Vollständigkeit/Befestigung). Intended condition: Keep the target component behind a realistic occluder or outside the viewing direction, without adding a visible defect. Missing visual evidence is the intended challenge.
Other visible components remain unchanged and plausible. If the requested fault is not visible from this angle, do not move it or invent another fault to reveal it. Occlusion is allowed and must later be annotated. A still photograph cannot establish human-only functionality.
Generate ONE separate image, landscape 1536x1024 if supported. Preserve source images/scene references for subsequent views. Independent image generation cannot guarantee geometric consistency: reject inconsistent assets during review. Do not claim image generation parameters or defect truth were measured.

