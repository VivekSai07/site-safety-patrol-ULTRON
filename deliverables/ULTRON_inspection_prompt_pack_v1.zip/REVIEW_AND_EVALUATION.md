# Review and evaluation

This ZIP contains prompts, NOT generated images or an evaluated dataset. 7 sections, 23 criteria, 4 condition variants per criterion = 92 scenarios. 8 azimuths x 3 vertical bands = 24 images/scenario, 2,208 full-grid image requests. first_batch_84.jsonl is a smaller 7 sections x 4 variants x 3 bands subset, not a completed 360 dataset.

All source images, edits, crops, condition variants and views sharing base_asset_group must stay in one split. The included provisional split is fixed by base group; it is not a calibrated benchmark. Repeated procedural identities/views are correlated. Real held-out physical ladder/session data stays separate and is required for real performance claims.

Inspect actual images for identity consistency, visible defect evidence, plausible structure, annotation leakage, accidental extra defects and real occlusion. Mark reviewed=true only with reviewer attribution and actual per-criterion observations. Reject invalid generations rather than trusting prompts. Collect varied camera quality/material/background independently of target labels. Intact-looking human-only fields are NOT_CHECKED, never evidence of functioning mechanisms.

Evaluate image-linked defect recall, false defect alarms, unknown/abstention rate, per-criterion visibility and evidence citation accuracy. Report counts and intervals when appropriate; unsafe-to-safe errors and abstentions both matter. Separate synthetic from real metrics. Freeze prompts/model after tuning; do not evaluate on the same cases used to choose prompts. Retain raw responses and broken/occluded/unreadable labels.

For label OCR, generated small text is not reliable ground truth; use verified real captures or separately rendered controlled text with known metadata. A generated sticker year is not an independently verified inspection date. No reuse/license or privacy rights for future real captures are inferred from these recipes.
