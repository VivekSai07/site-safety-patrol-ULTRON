# Start with this message in ChatGPT

Read this ZIP. I want PHOTOREALISTIC REAL-WORLD-STYLE construction-site image candidates for all seven nesseler ladder checklist sections. Use realistic photographs, never MuJoCo/simulator screenshots, CAD renders, cartoons or schematic ladders. They remain synthetic candidates for a real-camera perception dataset.
Generate images, not safety certificates. Begin with the first 3 records of first_batch_84.jsonl; generate each as ONE separate image using its prompt and exact filename. Do not produce collages or write labels/answers on the image. After review, continue in small explicit batches; do not claim thousands of images were generated.

For views of one scenario, use earlier views as references and preserve ladder geometry, component defects and environment. For condition variants keep lighting/background comparable, changing only the intended component condition. If identity drifts, flag/reject the result instead of claiming multi-view consistency. Requested 360 photographic viewpoints do not establish robot reachability.

Return generated images with filenames and a metadata list. Never claim that intended defects really appeared: leave reviewed=false. Do not invent measured geometry, real sensor provenance or qualified-inspector labels. Never output a functioning/safe result from appearance. For tiny text, generated lettering is unreliable: label it unreadable until verified. Use controlled real/text-rendered label crops later for OCR evaluation.

Then follow REVIEW_AND_EVALUATION.md. Do not upload images or train a model unless I separately request it.
