# ULTRON seven-section prompt pack v1

Open START_HERE_CHATGPT.md first. All image prompts request photorealistic REAL-WORLD construction-site photography for the real-camera perception dataset; no simulator/CAD/cartoon style. generation/ contains copy-paste prompts for all seven sections. scenario_matrix.jsonl defines 92 intended scenes. keyframe_prompts_360.jsonl expands 2,208 individual photographic viewpoints; first_batch_84.jsonl is the small starting batch. These are prompts, not images or reviewed annotations.

api_prompts/ contains the seven detailed inspection prompts, common instructions, exact dashboard-key rubric and strict response schema. Use these with the ULTRON assessment request builder; keep image IDs and all 23 criteria. Dashboard contract snapshot: feature/dashboard 42330758a62197122b56d56098a49c8c442350bc. It supports photos, item_photos and all seven checklist groups. The pack does not merge that branch or implement robot walking.

Full 360 capture is a required product acceptance gate. Missing sectors/bands must remain incomplete; no unsafe orbit, fabricated view, automatic safe verdict or hidden human check may be used to satisfy it.
